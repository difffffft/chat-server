import os

folder_path = r'C:\Users\67222\Desktop\hello'
os.makedirs(folder_path)