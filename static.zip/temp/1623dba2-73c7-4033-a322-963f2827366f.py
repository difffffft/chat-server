import datetime

now = datetime.datetime.now()
now