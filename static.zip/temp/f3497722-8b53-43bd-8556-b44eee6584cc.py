import os

folder_path = 'C:\\Users\\67222\\Desktop\\hello'

file_names = os.listdir(folder_path)

for i in range(10):
    old_name = os.path.join(folder_path, file_names[i])
    new_name = os.path.join(folder_path, f'{i+1}.txt')
    os.rename(old_name, new_name)