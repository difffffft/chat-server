import os

path = 'C:/Users/67222/Desktop/hello'

if not os.path.exists(path):
    os.makedirs(path)
    print('Folder created successfully!')
else:
    print('Folder already exists!')