import datetime

current_time = datetime.datetime.now()
str(current_time)